# PARES-AD

Code for *PARES-AD: An anatomical reference framework for MRI review in Alzheimer's disease*
(Lu, Huang, Wu, for the Alzheimer's Disease Neuroimaging Initiative; submitted to *Health Information Science and Systems*).

PARES-AD (Prespecified Anatomical Reference for Error Screening in Alzheimer's disease) checks the predictions of an
MRI classifier against a four-feature anatomical reference (hippocampal volume, entorhinal thickness, ventricular
volume, temporoparietal thickness). The reference gives an AD probability whose itemized contributions and
intercept sum to its log-odds, so each disagreement with the classifier can be traced feature by feature. Review
scores that add binary disagreement (A) or continuous reference opposition (P) to classifier confidence (C) rank
predictions for review under a fixed workload.

## Contents

| Path | Contents |
| --- | --- |
| `pares_ad/` | Library: sign-constrained reference and case report, review scores C/A/K/P and the committee score CE, fixed-budget review yield with participant- and center-cluster bootstrap, local cross-fitting (Cx/CEx/Ax/Px) |
| `demo/` | Synthetic source and target cohorts and an end-to-end demonstration |
| `tests/` | Synthetic unit tests; parity check against the saved scores of the original analysis (restricted data) |
| `paper_scripts/research_v2/` | The analysis scripts that produced the reported results, as run |
| `protocols/` | Dated analysis protocols, as recorded before each analysis |
| `docs/` | Data contract, map from manuscript elements to scripts, implementation notes |
| `PARITY_RESULT.txt` | Output of the parity check on the original data |

No participant-level ADNI or NACC data, predictions, model checkpoints or identifiers are included.

## Installation

Python 3.10 or newer. The library needs only numpy, pandas and scipy.

```sh
python -m pip install .                      # library
python -m pip install -r requirements-test.txt   # library + test dependencies
```

## Quick start

```sh
python tools/run_tests.py        # 17 synthetic tests
python demo/run_demo.py 200      # synthetic end-to-end example, 200 bootstrap resamples
python tools/verify_manifest.py  # file checksums
```

Minimal use of the library:

```python
from pares_ad import (fit_head, predict_head, design, extras, source_weights, source_target,
                      Cohort, run_boot, summarize)

w, y = source_weights(src), source_target(src)                      # source predictions with labels
head_C = fit_head(design(src), y, w)                                 # confidence score C
head_P = fit_head(design(src, extras(src, 'P')), y, w)               # C + continuous reference opposition
scores = {'C': predict_head(head_C, design(tgt)),
          'P': predict_head(head_P, design(tgt, extras(tgt, 'P')))}

cohort = Cohort('target', tgt, ['configuration_id'])
cohort.set_scores(scores)
pt, ptot, boots = run_boot(cohort, ['C', 'P'], 'participant', 2000, seed=1)
table = summarize('target', 'main', ['C', 'P'], pt, ptot, boots, [('P', 'C')], 'participant', 2000)
```

Required columns are listed in `docs/DATA_CONTRACT.md`.

## Reproducing the reported results

ADNI data are available from the LONI Image and Data Archive (https://ida.loni.usc.edu) and NACC data through the
NACC data request process (https://naccdata.org), under the respective data-use agreements. The scripts in
`paper_scripts/research_v2/` expect the original project layout (`data/` and `research_v2/outputs/` next to
`research_v2/src/`); `docs/REPRODUCIBILITY.md` lists which script produces each table, figure and supplementary
data file. The scripts use the pinned environment in `paper_scripts/requirements.txt` (PyTorch for the classifiers;
R for one data-extraction helper).

`tests/parity_with_saved_scores.py --root <project root>` checks this library against the saved scores and results
of the original analysis in ADNI and both NACC cohorts; its output is in `PARITY_RESULT.txt`.

## License and citation

MIT License (see `LICENSE`). Please cite the article above; the full reference will be added on publication.
