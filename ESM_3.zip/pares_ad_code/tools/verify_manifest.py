"""Verify package file bytes; does not execute research code or load participant data."""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[1]
checked = 0
expected = {'MANIFEST.sha256'}
for line in (ROOT / 'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
    digest, relative = line.split('  ', 1)
    expected.add(relative)
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():
        raise SystemExit('Missing or invalid manifest path: ' + relative)
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise SystemExit('Checksum mismatch: ' + relative)
    checked += 1
actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()
          and '__pycache__' not in p.parts and p.suffix not in {'.pyc', '.pyo'}}
extra = actual - expected
if extra:
    raise SystemExit('Unmanifested files: ' + ', '.join(sorted(extra)))
print('Verified', checked, 'file checksums.')
